package myDemo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
public class MainDemo {
	@Test
	public void invokeBrowser() {
			try {
//INVOKE FIREFOX	
				System.setProperty("webdriver.gecko.driver","C:\\Users\\Lavanya T\\Downloads\\firefoxdriver\\geckodriver.exe");
			   // DesiredCapabilities capabilities = DesiredCapabilities.firefox();
				WebDriver driver = new FirefoxDriver();
//MAXIMIZE WINDOW
				
				driver.manage().window().maximize();
//INVOKE WEBSITE
				
				driver.navigate().to("http://localhost:4200");

//SIN-UP AN ACCOUNT
				
				driver.findElement(By.xpath("/html/body/app-root/html/body/div/app-login/div[2]/a")).click();
				
//REGISTER ACCOUNT
				
				  driver.findElement(By.id("firstName")).sendKeys("abcdefgh");
				  driver.findElement(By.name("lastName")).sendKeys("uvwxyz");
				  driver.findElement(By.id("next")).click();
				  driver.findElement(By.name("email")).sendKeys("abc@gmail.com");
				  driver.findElement(By.xpath("/html/body/app-root/html/body/div/app-contact-details/div/form/router-outlet/div[2]/div/input")).sendKeys("1234567899");
				  driver.findElement(By.id("next")).click();
				  driver.findElement(By.xpath("/html/body/app-root/html/body/div/app-kyc-details/div/form/router-outlet/div[1]/div/input")).sendKeys("2020-08-04");
				  driver.findElement(By.name("pancard")).sendKeys("1234567891010");
				  driver.findElement(By.id("next")).click();
				  driver.findElement(By.id("addressLine1")).sendKeys("04");
				  driver.findElement(By.id("addressLine2")).sendKeys("gahdtkd");
				  driver.findElement(By.id("addressLine3")).sendKeys("thirubsdg");
				  driver.findElement(By.id("addressLine4")).sendKeys("ahgdjtf");
				  driver.findElement(By.id("addressLine5")).sendKeys("7089908");
				  driver.findElement(By.id("next")).click();
				  driver.findElement(By.id("userName")).sendKeys("heloihj");
				  driver.findElement(By.name("password")).sendKeys("uv2345@89");
				  driver.findElement(By.name("confirm_password")).sendKeys("uv2345@89");
				  driver.findElement(By.name("tnc")).click();
				  driver.findElement(By.xpath("/html/body/app-root/html/body/div/app-user-registration/div/form/router-outlet/div[5]/button")).click();
				  
//LOGIN ACCOUNT	
	
			driver.findElement(By.xpath("/html/body/app-root/html/body/app-navbar/nav/div/div/ul[2]/li[1]/a")).click();
			driver.findElement(By.name("username")).sendKeys("heloihj");
		    driver.findElement(By.name("passowrd")).sendKeys("uv2345@89");
		    driver.findElement(By.xpath("/html/body/app-root/html/body/div/app-login/div[1]/form/div[3]/button")).click();

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
 public static void main(String[] args)  {
           MainDemo ref = new MainDemo();
           ref.invokeBrowser();
}}

